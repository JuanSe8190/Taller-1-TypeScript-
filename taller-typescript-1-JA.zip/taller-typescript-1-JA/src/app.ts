import { series } from './data.js';
import { Serie } from './Serie.js';

const tbody: HTMLElement | null = document.getElementById('series-body');
const avgSpan: HTMLElement | null = document.getElementById('average');

function renderTable(items: Serie[]): void {
  if (!tbody) return;

  for (const s of items) {
    const tr = document.createElement('tr');

    const tdId = document.createElement('td');
    tdId.textContent = String(s.id);

    const tdName = document.createElement('td');
    tdName.textContent = s.name;

    const tdChannel = document.createElement('td');
    tdChannel.textContent = s.channel;

    const tdSeasons = document.createElement('td');
    tdSeasons.textContent = String(s.seasons);

    tr.appendChild(tdId);
    tr.appendChild(tdName);
    tr.appendChild(tdChannel);
    tr.appendChild(tdSeasons);
    tbody.appendChild(tr);
  }
}

function getAverageSeasons(items: Serie[]): number {
  if (items.length === 0) return 0;
  let total = 0;
  for (const s of items) {
    total = total + s.seasons;
  }
  return Math.round((total / items.length) * 100) / 100;
}

function renderAverage(avg: number): void {
  if (!avgSpan) return;
  avgSpan.textContent = String(avg);
}

renderTable(series);
renderAverage(getAverageSeasons(series));
